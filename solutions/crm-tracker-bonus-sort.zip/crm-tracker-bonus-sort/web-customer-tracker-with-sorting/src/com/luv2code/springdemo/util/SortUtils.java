package com.luv2code.springdemo.util;

public interface SortUtils {
	
	public static final int FIRST_NAME = 1;
	public static final int LAST_NAME = 2;
	public static final int EMAIL = 3;

}
